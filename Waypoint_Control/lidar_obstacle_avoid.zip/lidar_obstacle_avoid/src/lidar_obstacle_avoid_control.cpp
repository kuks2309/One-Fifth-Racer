#define DEBUG 0
#define DEBUG_ROS_INFO 1 
#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Int16.h"
#include "std_msgs/Int8.h"
#include "geometry_msgs/Twist.h"
#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/Range.h"
#include "tf/transform_broadcaster.h"
#include "nav_msgs/Odometry.h"
#include "visualization_msgs/Marker.h"
#include "visualization_msgs/MarkerArray.h"
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/MagneticField.h>
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"

#include<string.h>
#include "obstacle_processing.h"
          
#define RAD2DEG(x) ((x)*180./M_PI)
#define DEG2RAD(x) ((x)/180.*M_PI)
// unit : m
#define Sonar_Detect_Range 0.3
#define MAX_Obstacle_dist 5 //[m]
#define LIDAR_Obstacle   1
#define LIDAR_Obstacle_angle 20
#define LIDAR_Obstacle_avoid_angle 15
#define LIDAR_Side_Detection 0.25
#define LIDAR_Side_Detection_anlge 10

#define OFF 0
#define ON  1

struct Point 
{ 
	float x;
	float y;
	float z;
};

double roll,pitch,yaw;
double roll_d,pitch_d,yaw_d;
int heading_angle = 90;
int initial_heading_angle = 0;
int steer_angle = 0;
int steer_angle_wall = 0;
int status_avoidance_control = OFF;

void imuCallback(const sensor_msgs::Imu::ConstPtr& msg) 
{
  /*
   *   ROS_INFO( "Accel: %.3f,%.3f,%.3f [m/s^2] - Ang. vel: %.3f,%.3f,%.3f [deg/sec] - Orient. Quat: %.3f,%.3f,%.3f,%.3f",
              msg->linear_acceleration.x, msg->linear_acceleration.y, msg->linear_acceleration.z,
              msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z,
              msg->orientation.x, msg->orientation.y, msg->orientation.z, msg->orientation.w);
    */        
      tf2::Quaternion q(
        msg->orientation.x,
        msg->orientation.y,
        msg->orientation.z,
        msg->orientation.w);
      tf2::Matrix3x3 m(q);
      
 
      m.getRPY(roll, pitch, yaw);
      
     // printf("%6.3lf(rad)  %6.3lf \n",yaw, yaw*180/3.14159);
              
}


void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
    int count = (int)(360. / RAD2DEG(scan->angle_increment));
    double *obstacle;
    
    int sum=0; 
    int sum_l = 0, sum_r = 0;
    double dist_y = 0.0; 
    int max=-1;
    int max_i = -1;
    int left_wall_sum = 0;
    double left_wall_min_distance  = MAX_Obstacle_dist;
    double right_wall_min_distance = MAX_Obstacle_dist;
    int right_wall_sum = 0;
    
    
    obstacle = new double[181];
    for(int i =0;i<181;i++) obstacle[i] = MAX_Obstacle_dist; 
    
   // ROS_INFO("I heard a laser scan %s[%d]:", scan->header.frame_id.c_str(), count);
   // ROS_INFO("%f %f",scan->scan_time , scan->time_increment);
   // ROS_INFO("%d angle_range, %f, %f %f", count,RAD2DEG(scan->angle_min), RAD2DEG(scan->angle_max), RAD2DEG(scan->angle_increment));
  
    for(int i = 0; i < count; i++)
    {
		int degree = (int)RAD2DEG(scan->angle_min + scan->angle_increment * i);
        
        if( (degree>=0) && (degree<90) ) 		
		{
			
			double temp = fabs((scan->ranges[i])*cos(DEG2RAD(degree)));
			if( temp<= LIDAR_Side_Detection )  right_wall_sum++;
			
			if( temp <= left_wall_min_distance )  left_wall_min_distance = temp;
		}
		
		if( (degree>=270) && (degree<360) ) 		
		{
			double temp = fabs((scan->ranges[i])*cos(DEG2RAD(degree)));
			if( temp <= LIDAR_Side_Detection ) left_wall_sum++;
			
			if( temp <= right_wall_min_distance )  right_wall_min_distance = temp;
			
		}
        
        
        if(scan->ranges[i] <= LIDAR_Obstacle)
        {
		   if( ( (degree>=0) && (degree < LIDAR_Obstacle_angle)  ) || ( (degree>=360-LIDAR_Obstacle_angle) && (degree<360)  ))
		   { 
			   sum++;
		   }
			
		   if( (degree>=0) && (degree<90) ) 
		   { 
			   obstacle[degree+90] = (scan->ranges[i]);
			//   printf("%d %d\n", degree,degree+90);
		   }
		   if( (degree>=270) && (degree<360) ) 
		   { 
			   obstacle[degree-270] = (scan->ranges[i]);
		   }
	    }
	    
       // ROS_INFO(": [%3d, %5d]", degree, obstacle[degree] );
      
    }
    
    double *no_obstacle_center_position;
    CSize *Projection_Blob_Size;
    int no_blob;
    no_obstacle_center_position = new double[50];
	Projection_Blob_Size = new CSize[50];
	memset(no_obstacle_center_position, 0, 50 * sizeof(double));
    
    //(double *projection, int size_projection,  threshold, double *position, int *no_pad, CSize* Projection_Blob);
     Find_ProjectData_Center_Position(obstacle, 180, MAX_Obstacle_dist,no_obstacle_center_position, &no_blob,Projection_Blob_Size);  
     printf("sum = %d, Blob no %d  \n", sum,no_blob);
     
     printf("Wall Detection %d %d \n", left_wall_sum,right_wall_sum);
     steer_angle_wall = 0;
     if(sum <= 3) 
     {
		if((left_wall_sum !=0) && (right_wall_sum !=0))
		{    
		    
		      heading_angle    = 0;    
		      
		      if(left_wall_min_distance > right_wall_min_distance )        steer_angle_wall = 7;
		      else if(left_wall_min_distance < right_wall_min_distance )  steer_angle_wall = -7;
		      else steer_angle_wall = 0;
		      //status_avoidance_control = ON;
		}
		
		else if ((left_wall_sum == 0) && (right_wall_sum !=0))
		{
			  steer_angle_wall = heading_angle = LIDAR_Side_Detection_anlge;
			 // status_avoidance_control = ON;
		}
		else if ((left_wall_sum !=0) && (right_wall_sum ==0) )
		{
			  steer_angle_wall =heading_angle = -LIDAR_Side_Detection_anlge;
			 // status_avoidance_control = ON;
			
		}
		else 		
		{  
			heading_angle = 0;
			//status_avoidance_control = OFF;
		}
		status_avoidance_control = OFF;
		printf("Heading Angle = %d\n",heading_angle);
        printf("%6.3lf(rad)  %6.3lf \n",yaw, yaw*180/3.14159);
        return;
	 }
     for(int i=0;i<no_blob;i++)
     {
		 printf("%d : [%3d %3d]\n", i, Projection_Blob_Size[i].cx,Projection_Blob_Size[i].cy);
		 int distance = fabs(Projection_Blob_Size[i].cx- Projection_Blob_Size[i].cy);
		 if(max <=  distance)
		 {
			 max = distance ;
			 max_i = i;
		 }
	 }
	 
	// printf("%d %d [%3d %3d]\n", max_i, max,Projection_Blob_Size[max_i].cx,Projection_Blob_Size[max_i].cy);
	 
     double temp_angle  = 90-(max,Projection_Blob_Size[max_i].cx+Projection_Blob_Size[max_i].cy)/2;
     
     if( (temp_angle >= 0)   && (temp_angle <90) )
     {
		 int min = 100;
		 if(min >= abs(Projection_Blob_Size[max_i].cx) )  min = Projection_Blob_Size[max_i].cx;
		 if(min >= abs(Projection_Blob_Size[max_i].cy) )  min = Projection_Blob_Size[max_i].cy;
		 min += LIDAR_Obstacle_avoid_angle;
		 printf("min = %d \n",min);		 
	 }
	 
	 if( (temp_angle >= -90)   && (temp_angle <0) )
     {
		 int min = 100;
		 if(min >= abs(Projection_Blob_Size[max_i].cx) )  min = Projection_Blob_Size[max_i].cx;
		 if(min >= abs(Projection_Blob_Size[max_i].cy) )  min = Projection_Blob_Size[max_i].cy;
		 min -= LIDAR_Obstacle_avoid_angle;
		 printf("min = %d \n",min);		 
	 }
     		
     if( (temp_angle<= 90)   &&(temp_angle >=-90))
     {
		 status_avoidance_control = ON;
		 heading_angle = temp_angle+steer_angle_wall;
	 }    
     printf("Heading Angle = %d\n",heading_angle);
     printf("%6.3lf(rad)  %6.3lf \n",yaw, yaw*180/3.14159);
    
     delete []obstacle;
}

int main(int argc, char **argv)
{
  char buf[2];
  ros::init(argc, argv, "lidar_obstacle_avoid");

  ros::NodeHandle n;  
  std::string lidar_topic = "/scan";
  std::string sonar1_topic = "/RangeSonar1";
  std::string sonar2_topic = "/RangeSonar2";
  std::string sonar3_topic = "/RangeSonar3";
  std::string imu_topic = "/handsfree/imu";
  std::string odom_pub_topic = "/odom";
  std::string init_heading_angle = "/scan";
  std::string status_avoid_contol_topic ="/lidar_avoid_control_status"; 
  
  char frameid[] ="/sonar_range";
  
  /*other*/
  ros::param::get("~lidar_topic", lidar_topic);
  ros::param::get("~imu_topic", imu_topic);
  ros::param::get("~sonar1_topic", sonar1_topic);
  ros::param::get("~sonar2_topic", sonar2_topic);
  ros::param::get("~sonar3_topic", sonar3_topic);
  ros::param::get("~odom_pub_topic", odom_pub_topic);
  ros::param::get("~status_void_contol", status_avoid_contol_topic);
  
  
  ros::Subscriber sub_IMU = n.subscribe(imu_topic, 20, imuCallback);
  ros::Subscriber sub_lidar = n.subscribe<sensor_msgs::LaserScan>(lidar_topic, 10, &scanCallback);
 // ros::Subscriber sub_sonar1 = n.subscribe<sensor_msgs::Range>(sonar1_topic, 1000, &sonar1Callback);
 // ros::Subscriber sub_sonar2 = n.subscribe<sensor_msgs::Range>(sonar2_topic, 1000, &sonar2Callback);
 // ros::Subscriber sub_sonar3 = n.subscribe<sensor_msgs::Range>(sonar3_topic, 1000, &sonar3Callback);
  
  ros::Publisher lidar_boat_control_pub1 = n.advertise<std_msgs::Int16>("/Boat_Control_cmd/lidar_steerAngle_Int16", 10);
  ros::Publisher lidar_boat_control_pub2 = n.advertise<std_msgs::Int16>("/Boat_Control_cmd/lidar_Speed_Int16", 10);
  ros::Publisher obstacle_control_status_pub = n.advertise<std_msgs::Int8>(status_avoid_contol_topic, 10);
  
  ros::Publisher marker_pub = n.advertise<visualization_msgs::MarkerArray>("marker/node", 1);

  ////////////////  pid control //////////////////////
  double error, error_old, error_d, error_sum;
  double pi_gain,pd_gain,p_gain;
  
  
  error = error_old = error_d = error_sum = 0.0;
  p_gain = 1.7;
  pd_gain = 3; 
  
  ////////////////   imu _sensor //////////////////////
  sensor_msgs::Imu imu_data;
  roll = pitch = yaw = 0.0;
  ////////////////   sonar _sensor //////////////////////
  sensor_msgs::Range sonar_msg;
  sonar_msg.header.frame_id =  frameid;
  sonar_msg.radiation_type = sensor_msgs::Range::ULTRASOUND;
  sonar_msg.field_of_view = (30.0/180.0) * 3.14;
  sonar_msg.min_range = 0.0;
  sonar_msg.max_range = 1.50;  //[unit :m]
  
  ////////////////// Visaul Makrer /////////////////////////
  Point p; 
  std::vector<Point> vec_point; 
  for(int i=0; i<1; i++) 
  { 
	  p.x = i; p.y = i; p.z = i; 
	  vec_point.push_back(p); 
  }

  visualization_msgs::MarkerArray node_link_arr;
 
   

  /**
   * A count of how many messages we have sent. This is used to create
   * a unique string for each message.
   */
  int count = 0;
  
 
  ros::Rate loop_rate(5);  // 10
  
  while (ros::ok())
  {
    /**
     * This is a message object. You stuff it with data, and then publish it.
     */
     for (size_t i = 0; i < vec_point.size(); i++)
     { 
		  visualization_msgs::Marker node_link; 
		  node_link.header.frame_id = "/base_link"; 
		  node_link.header.stamp = ros::Time::now(); 
		  node_link.id = i*10; 
		  node_link.action = visualization_msgs::Marker::ADD; 
		  node_link.pose.orientation.w = 1.0; 
		  // Points are green 
		  node_link.color.g = 1.0f; 
		  node_link.color.a = 1.0; 
		  node_link.scale.x = 0.1; 
		  node_link.scale.y = 0.2; 
		  node_link.type = visualization_msgs::Marker::ARROW; 
		  geometry_msgs::Point start_p, end_p; 
		  start_p.x = 0; 
		  start_p.y = 0; 
		  node_link.points.push_back(start_p); 
		  end_p.x = 1.0*cos(DEG2RAD(heading_angle)); 
		  end_p.y = 1.0*sin(DEG2RAD(heading_angle)); 
		  node_link.points.push_back(end_p); 
		  node_link_arr.markers.push_back(node_link); 
		  
  } 
    marker_pub .publish(node_link_arr);
    
    double angle_temp = (double)heading_angle;
    
    error = angle_temp ;
	error_d = error - error_old;
	
	steer_angle = (int)( p_gain * error + pd_gain * error_d  + 0.5   );
	
	printf("steer angle %d \n", steer_angle);
		
	std_msgs::Int16 s_angle;
	s_angle.data =  -steer_angle%360;
	lidar_boat_control_pub1.publish(s_angle);
	
	
	std_msgs::Int8 avoidance_control_status;
	avoidance_control_status.data = status_avoidance_control ;
	obstacle_control_status_pub.publish(avoidance_control_status);
		status_avoidance_control = OFF;
	error_old = error;
    loop_rate.sleep();
    ros::spinOnce();
    ++count;
  }
  
  return 0;
}



