#include "ros/ros.h" 
#include "geometry_msgs/Twist.h"
#include "std_msgs/Bool.h"
#include "std_msgs/Int8.h"
#include "std_msgs/Int16.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Float32.h"
#include "sensor_msgs/Imu.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"

#define _USE_MATH_DEFINES

#include <math.h>
#include <iostream>

using namespace std;

#define MAX_angluar_velocity M_PI/10

#define RAD2DEG(x) ((x)*180./M_PI)
#define DEG2RAD(x) ((x)/180.*M_PI)

double roll,pitch,yaw;
double roll_d,pitch_d,yaw_d, yaw_d_360;
double yaw_d_old  = 0.;
double target_yaw = 0.;

double Kp        = 0.01;
double Kd        = 0.04;
double Ki        = 0.00;
double error     = 0.0;
double error_d   = 0.0;
double error_sum = 0.0;

double imu_heading_angle        = 0.0;                 // radain 값으로 imu에서 나오는 heading_angle(yaw)
double imu_heading_angle_d      = 0.0;                 // radain 값으로 imu에서 나오는 heading_angle(yaw) ~180 ~ 180 
double imu_heading_angle_d_360  = 0.0;                 // radain 값으로 imu에서 나오는 heading_angle(yaw)  0~360
double imu_heading_anlge_offset = 0.0;

bool   control_action_flag  = 0;
bool   use_imu = false;

int right_angle_max = -25;
int left_angle_max  = 25;

void imuCallback(const sensor_msgs::Imu::ConstPtr& msg) 
{
    /*
    *   ROS_INFO( "Accel: %.3f,%.3f,%.3f [m/s^2] - Ang. vel: %.3f,%.3f,%.3f [deg/sec] - Orient. Quat: %.3f,%.3f,%.3f,%.3f",
              msg->linear_acceleration.x, msg->linear_acceleration.y, msg->linear_acceleration.z,
              msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z,
              msg->orientation.x, msg->orientation.y, msg->orientation.z, msg->orientation.w);
    */        
    tf2::Quaternion q(
        msg->orientation.x,
        msg->orientation.y,
        msg->orientation.z,
        msg->orientation.w);
        tf2::Matrix3x3 m(q);     
 
    m.getRPY(roll, pitch, yaw);
      
    //printf("%6.3lf(rad)  %6.3lf \n",yaw, yaw*180/3.14159);
    //yaw_d = RAD2DEG(yaw);
    
    //yaw_d_360 = (yaw_d < 0) ? yaw_d + 360 : yaw_d;
     
}

void imu_yaw_Callback(const std_msgs::Float32& msg)
{
	imu_heading_angle = msg.data;
	imu_heading_angle_d = RAD2DEG(imu_heading_angle) + imu_heading_anlge_offset;;
	
	imu_heading_angle_d_360 = (imu_heading_angle_d < 0) ? imu_heading_angle_d + 360 : imu_heading_angle_d;
	
}

void imu_yaw_offset_Callback(const std_msgs::Float32& msg)
{
	
	imu_heading_anlge_offset = msg.data;
}

void gps_heading_angle_Callback(const std_msgs::Float32& msg)
{
	yaw   = msg.data;
	yaw_d = RAD2DEG(yaw) ;
	yaw_d_360 = (yaw_d < 0) ? yaw_d + 360 : yaw_d;
}

void target_yaw_Callback(const std_msgs::Float32& msg)
{
	int     quotient  = 0  ;
	double  remainder = 0.0;
	target_yaw = msg.data ;
	//if(target_yaw < 0) target_yaw +=360;
	
	quotient  = target_yaw/360;
	target_yaw = target_yaw - 360*quotient;
	
	if(target_yaw  <-180)
	{
		target_yaw += 360;		
	}
	
	//target_yaw  =  (target_yaw >=  180) ? (target_yaw -360.0) : target_yaw;
	control_action_flag = 1;
}


double control_yaw(void)
{
	double steering_angle_control = 0;
	double yaw_d1;
	//int     quotient  = 0  ;
	//double  remainder = 0.0;
	int error_d = 0;
	double error1;

    //printf("sin(%6.3lf - %6.3lf) = %6.3lf\n ", target_yaw, yaw_d, CW_flag );
    //printf("error %6.3lf  %6.3lf \n", error1, error2);

	if( use_imu == 0)
	{
		error1 = target_yaw - yaw_d;	
	}
	else
	{
		error1 = target_yaw - imu_heading_angle_d;	
	}
	 
	
	if(error1 >= 180)  error1 = error1 - 360;
    if(error1 <=-180)  error1 = error1 + 360;
     
    /*       
    if( (target_yaw > 179) || (target_yaw < -179))
    {
		error1 = target_yaw - yaw_d_360;		
	
	} 		
	*/
	
    error = error1;
    //if(fabs(error1) > fabs(error2))  error = error2;
    //else error = error2;
    
	steering_angle_control = Kp * error + Kd * error_d + Ki * error_sum;
	
	error_d = error;
	yaw_d_old = yaw_d1;
	
	if( steering_angle_control <= right_angle_max )  steering_angle_control = right_angle_max;
	if( steering_angle_control >= left_angle_max )   steering_angle_control =  left_angle_max;
	if( use_imu == 0)
	{	
		ROS_INFO("GPS Yaw Angle : %6.3lf %6.3lf Target Yaw : %6.3lf Error : %6.3lf | steer angle %6.3lf",yaw_d,yaw_d_360,target_yaw,error,steering_angle_control );
	}
	else
	{
		ROS_INFO("IMU Yaw Angle : %6.3lf %6.3lf Target Yaw : %6.3lf Error : %6.3lf | steer angle %6.3lf",imu_heading_angle_d,imu_heading_angle_d_360,target_yaw,error,steering_angle_control );
	}
	
	return steering_angle_control;
}

int main(int argc, char **argv)
{
 
  double pid_output = 0.0;
  ros::init(argc, argv, "car_yaw_control_node");
  ros::NodeHandle n;
  
  std::string imu_topic                          = "/handsfree/imu";
  std::string imu_yaw_angle_topic                = "/handsfree/imu_yaw_radian";
  std::string gps_heading_angle_topic            = "/gps_heading_angle";
  
  std::string yaw_target_topic                   = "/Car_Control_cmd/Target_Angle";
  std::string yaw_control_steering_output_topic  = "/Car_Control_cmd/SteerAngle_Int16";
   
  std::string imu_yaw_offset_angle_topic         = "/imu/yaw_offset_degree";
  
  ros::param::get("~use_imu", use_imu);     
  
  ros::param::get("~imu_topic", imu_topic);     
  ros::param::get("~imu_yaw_angle_topic", imu_yaw_angle_topic);     
  ros::param::get("~gps_heading_angle",  gps_heading_angle_topic);
  ros::param::get("~imu_yaw_offset_angle_topic",  imu_yaw_offset_angle_topic);
  
  ros::param::get("~yaw_target_topic",  yaw_target_topic);                                      
  ros::param::get("~yaw_control_steering_output_topic",  yaw_control_steering_output_topic);
  
  ros::param::get("~Kp", Kp);  
  ros::param::get("~Kd", Kd);  
  ros::param::get("~Ki", Ki);  
  
  ros::param::get("~left_angle_max", left_angle_max);
  ros::param::get("~right_angle_max", right_angle_max);
  
  
  cout << "use imu : " << use_imu << endl;  
  cout << "imu_topic : " << imu_topic << endl;
  cout << "imu_yaw_angle_topic : " << imu_yaw_angle_topic <<endl;
  cout << "gps_heading_angle_topic :" << gps_heading_angle_topic  <<endl;
   
 
  cout << "yaw_target_topic : " << yaw_target_topic <<  endl;    
  cout << "yaw_control_steering_output_topic : " << yaw_control_steering_output_topic << endl;  
  
  
  roll = pitch = yaw = roll_d = pitch_d = yaw_d = yaw_d_old = 0.0;
  
  geometry_msgs::Vector3 rpy_angle_radian;
  geometry_msgs::Vector3 rpy_angle_degree;
  
  std_msgs::Int16 steering_angle;
   
   
  ros::Subscriber sub_IMU                            =  n.subscribe(imu_topic, 20, imuCallback);
  ros::Subscriber sub_IMU_yaw_angle                  =  n.subscribe(imu_yaw_angle_topic, 20, imu_yaw_Callback);
  ros::Subscriber sub_IMU_yaw_offset_angle           =  n.subscribe(imu_yaw_offset_angle_topic, 20, imu_yaw_offset_Callback);
  ros::Subscriber sub_gps_heading_angle              =  n.subscribe(gps_heading_angle_topic,1,gps_heading_angle_Callback);
    
  ros::Subscriber sub_target_yaw                     =  n.subscribe(yaw_target_topic, 10, target_yaw_Callback); 
  
  ros::Publisher  yaw_control_steering_output_pub    =  n.advertise<std_msgs::Int16>(yaw_control_steering_output_topic, 2);
  
  ros::Rate loop_rate(25.0); //10.0HZ
  
  while(ros::ok())
  {
      rpy_angle_radian.x = roll;
      rpy_angle_radian.y = pitch;
      rpy_angle_radian.z = yaw;
      
      rpy_angle_degree.x = roll_d;
      rpy_angle_degree.y = pitch_d;
      rpy_angle_degree.z = yaw_d;
      
      if(control_action_flag == 1)
      {
        pid_output = control_yaw();
        steering_angle.data = pid_output;
        yaw_control_steering_output_pub.publish(steering_angle);    
	  }
      else
      {
		ROS_WARN("No target_angle");  
	  }
	  
      ros::spinOnce();
      loop_rate.sleep();
  }

  return 0;
}
